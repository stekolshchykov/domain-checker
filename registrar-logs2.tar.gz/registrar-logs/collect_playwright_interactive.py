import asyncio
from playwright.async_api import async_playwright

TEST_DOMAINS = [
    ("driftnest.io", ".io"),
    ("example.com", ".com"),
    ("sparknode.com", ".com"),
]


async def collect_letshost(page, domain, tld):
    await page.goto("https://billing.letshost.ie/domainchecker.php", wait_until="networkidle", timeout=30000)
    # Fill domain and select TLD via JS to bypass cookie banner
    await page.evaluate(f"""
        document.querySelector('#inputDomain').value = '{domain.replace(tld, "")}';
        const cb = document.querySelector('input[name="tld[]"][value="{tld}"]');
        if (cb) cb.checked = true;
        document.querySelector('#btnCheckAvailability').click();
    """)
    # Wait for results table to populate
    try:
        await page.wait_for_selector("#bulkDomainsResults tbody tr", timeout=15000)
    except Exception:
        pass
    text = await page.content()
    filename = f"/app/registrar-logs/letshost_interactive_{domain.replace('.', '_')}.html"
    with open(filename, "w", encoding="utf-8") as f:
        f.write(text)
    print(f"Saved {filename} ({len(text)} chars)")


async def main():
    async with async_playwright() as p:
        browser = await p.firefox.launch(headless=True)
        page = await browser.new_page()

        for domain, tld in TEST_DOMAINS:
            print(f"\n=== {domain} ===")
            await collect_letshost(page, domain, tld)
            await asyncio.sleep(1)

        await browser.close()
    print("\nDone.")


if __name__ == "__main__":
    asyncio.run(main())
