import asyncio
from playwright.async_api import async_playwright

TEST_DOMAINS = [
    "driftnest.io",
    "example.com",
    "nexusscape.io",
    "fablenode.io",
    "sparknode.com",
]


async def collect_page(page, name: str, domain: str, url: str):
    try:
        await page.goto(url, wait_until="networkidle", timeout=20000)
        text = await page.content()
        filename = f"/app/registrar-logs/{name}_{domain.replace('.', '_')}.html"
        with open(filename, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"Saved {filename} ({len(text)} chars)")
    except Exception as e:
        filename = f"/app/registrar-logs/{name}_{domain.replace('.', '_')}.html"
        with open(filename, "w", encoding="utf-8") as f:
            f.write(f"ERROR: {e}")
        print(f"Error {name} {domain}: {e}")


async def main():
    async with async_playwright() as p:
        browser = await p.firefox.launch(headless=True)
        page = await browser.new_page()

        for domain in TEST_DOMAINS:
            print(f"\n=== {domain} ===")
            parts = domain.rsplit(".", 1)
            sld, tld = parts if len(parts) == 2 else (domain, "com")

            await collect_page(
                page,
                "godaddy_pw",
                domain,
                f"https://www.godaddy.com/en/domainsearch/find?checkAvail=1&domainToCheck={domain}",
            )
            await collect_page(
                page,
                "cloudflare_pw",
                domain,
                f"https://domains.cloudflare.com/?domain={domain}",
            )
            await collect_page(
                page,
                "letshost_pw",
                domain,
                f"https://billing.letshost.ie/domainchecker.php",
            )
            # Also try cart page for letshost
            await collect_page(
                page,
                "letshost_cart_pw",
                domain,
                f"https://billing.letshost.ie/cart.php?a=add&domain=register&query={domain}",
            )
            await asyncio.sleep(1)

        await browser.close()
    print("\nDone.")


if __name__ == "__main__":
    asyncio.run(main())
