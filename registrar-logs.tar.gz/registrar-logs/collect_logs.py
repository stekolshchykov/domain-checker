import asyncio
import json
import os
from datetime import datetime

import httpx

TEST_DOMAINS = [
    "driftnest.io",
    "example.com",
    "nexusscape.io",
    "fablenode.io",
    "sparknode.com",
]

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate, br",
    "DNT": "1",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
}


def save(name: str, domain: str, content: str):
    filename = f"{name}_{domain.replace('.', '_')}.html"
    path = os.path.join("/app/registrar-logs", filename)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"Saved {path} ({len(content)} chars)")


async def collect_godaddy(client: httpx.AsyncClient, domain: str):
    parts = domain.rsplit(".", 1)
    if len(parts) != 2:
        return
    sld, tld = parts

    # API
    api_url = f"https://www.godaddy.com/domainfind/v1/search/exact?q={sld}&tld={tld}"
    try:
        r = await client.get(api_url, headers={**HEADERS, "Accept": "application/json, text/plain, */*"})
        save("godaddy_api", domain, f"STATUS: {r.status_code}\n\n{r.text}")
    except Exception as e:
        save("godaddy_api", domain, f"ERROR: {e}")

    # HTML fallback
    fallback_url = f"https://www.godaddy.com/en/domainsearch/find?checkAvail=1&domainToCheck={domain}"
    try:
        r = await client.get(fallback_url, headers=HEADERS)
        save("godaddy_html", domain, r.text)
    except Exception as e:
        save("godaddy_html", domain, f"ERROR: {e}")


async def collect_cloudflare(client: httpx.AsyncClient, domain: str):
    # API
    api_url = f"https://api.cloudflare.com/client/v4/zones/name/available/{domain}"
    try:
        r = await client.get(api_url, headers={**HEADERS, "Accept": "application/json, text/plain, */*"})
        save("cloudflare_api", domain, f"STATUS: {r.status_code}\n\n{r.text}")
    except Exception as e:
        save("cloudflare_api", domain, f"ERROR: {e}")

    # HTML page
    search_url = f"https://domains.cloudflare.com/?domain={domain}"
    try:
        r = await client.get(search_url, headers=HEADERS)
        save("cloudflare_html", domain, r.text)
    except Exception as e:
        save("cloudflare_html", domain, f"ERROR: {e}")


async def collect_letshost(client: httpx.AsyncClient, domain: str):
    parts = domain.rsplit(".", 1)
    if len(parts) != 2:
        return
    sld, tld = parts

    url = "https://billing.letshost.ie/domainchecker.php"
    try:
        r = await client.post(
            url,
            data={"domain": sld, "tld[]": f".{tld}"},
            headers={
                **HEADERS,
                "Content-Type": "application/x-www-form-urlencoded",
                "Referer": "https://billing.letshost.ie/",
                "Origin": "https://billing.letshost.ie",
            },
        )
        save("letshost_post", domain, f"STATUS: {r.status_code}\nHEADERS: {dict(r.headers)}\n\n{r.text}")
    except Exception as e:
        save("letshost_post", domain, f"ERROR: {e}")

    # Also try GET with query params
    try:
        r = await client.get(
            f"https://billing.letshost.ie/cart.php?a=add&domain=register&query={domain}",
            headers=HEADERS,
        )
        save("letshost_cart", domain, f"STATUS: {r.status_code}\nHEADERS: {dict(r.headers)}\n\n{r.text}")
    except Exception as e:
        save("letshost_cart", domain, f"ERROR: {e}")


async def main():
    async with httpx.AsyncClient(timeout=15.0, follow_redirects=True) as client:
        for domain in TEST_DOMAINS:
            print(f"\n=== Collecting for {domain} ===")
            await collect_godaddy(client, domain)
            await collect_cloudflare(client, domain)
            await collect_letshost(client, domain)
            await asyncio.sleep(1)
    print("\nDone.")


if __name__ == "__main__":
    asyncio.run(main())
